myApp.controller("bookDeleteController",function($scope){
    
})
