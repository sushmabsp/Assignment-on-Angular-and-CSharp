myApp.controller("bookDisplayController",function($scope){
    $scope.content="Book Details";
    $scope.bookArr=[
    {BookId:101,BookName:"Adventures of Tom Sawyer",image:'D:\\tomsawyer.jfif',Author:"Mark Twain",
    Description:"Tom Sawyer is 12 years old and lives with his Aunt Polly, his half-brother Sid and his cousin Mary in S.Petersburg, a small town along the Mississippi River. Because Tom went to school and made his clothes dirty in a fight, he gets punished and he had to whitewash the fence Because he does not want to do this, he tells some boys what a “pleasure” it is to do the work His plan works and the boys even pay him for this.",price:100},
    {BookId:102,BookName:"Animal Farm",image:"D:\\animalfarm.jpg",Author:"George Orwell",
    Description:"Manor Farm is run by Mr Jones, a cruel and drunken farmer. One day, the animals gather at a meeting to listen to Old Major, a wise old pig. Old Major makes a speech, calling for animals to rise up against their farmers. The animals are very keen about the idea. Old Major dies a few days later. The pigs, who are the most intelligent animals, begin planning a rebellion. They are led by Snowball and Napoleon.",price:2000},
    {BookId:103,BookName:"Arthashastra",image:"D:\\arthasastra.jfif",Author:"Kautilya",
    Description:"The authorship and date of writing are unknown, and there is evidence that the surviving manuscripts[which?] are not original and have been modified in their history but were most likely completed in the available form between 2nd-century BCE to 3rd-century CE.[28] Olivelle states that the surviving manuscripts of the Arthashastra are the product of a transmission that has involved at least three major overlapping divisions or layers, which together consist of 15 books, 150 chapters and 180 topics.",price:2000},
    {BookId:104,BookName:"Time Machine",image:"D:\\timemachine.jfif",Author:"H.G. Wells",
    Description:"The Time Traveler tells an after-dinner group of men, including the narrator, that he has invented a Time Machine. He shows them a smaller prototype, and when he pulls a lever, it disappears--into the future, he claims. At the next week's dinner, the TT comes in midway through the meal, haggard and limping. He tells them of his eight days of time travel: The TT (now narrating the story) uses the Time Machine that morning and speeds forward through time. (Description of his journey will be recounted in present tense.",price:3000}];
    $scope.selectedBook={};
    $scope.showEditBook=false;
    
    $scope.editBookDetailsEventHandler=function(obj){
        $scope.selectedBook=obj;
        alert("U have selected BookId :"+ obj.BookId + " to edit");
        $scope.showEditBook=true;
    }

    
    $scope.showAddBook=false;
    $scope.showAddNewBookEventHandler=function()
    {
        
        $scope.showAddBook=true;
        // for(let key in newBook)
        // {
        //     newBook[key] = " ";
        // }
           
    }

    $scope.$on("Addnewbook",function(event,newBook){
        console.log(newBook);
        $scope.bookArr.push(newBook); 
        $scope.showAddBook=false; 
    }) 
    $scope.$on("cancelAddnewBook",function(){
        $scope.showAddBook=false;
    })



    $scope.deleteBookDetailsEventHandler=function(bookToBeDeleted)
    {
        var pos=$scope.bookArr.findIndex(item=> {
            if(item.BookId == bookToBeDeleted.BookId)
            {
                return true;
            }
            else
            {
                return false;
            }
        })
        $scope.bookArr.splice(pos,1);
        console.log(bookToBeDeleted);
    }
    
    $scope.saveEditDetailsEventHandler = function()
    {
        $scope.showEditBook=false;
    }
})
