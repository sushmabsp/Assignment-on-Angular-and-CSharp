﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace booklist
{

    class Book
    {
        public string bookId,bookName, Author,description;
        public float price;


        public Book(string bookId, string bookName, string Author, float price, string description)
        {
            this.bookId = bookId;
            this.bookName = bookName;
            this.Author = Author;
            this.price = price;
            this.description = description;
        }
        public Book(Book obj)
        {
            this.bookId = obj.bookId;
            this.bookName = obj.bookName;
            this.Author = obj.Author;
            this.price = obj.price;
            this.description = obj.description;
        }

        public override string ToString()
        {
            return $"Book Id : {bookId}, BookName : {bookName}, Author : {Author}, Price : {price}, Description: {description}";
        }


    }
    
    

        class Program
        {
            static void displayBookDetails(List<Book> list)
            {
                foreach (Book item in list)
                {
                    Console.WriteLine(item);
                }
            }


            public static void Main(string[] args)
            {
                int num, num1;
                List<Book> booklist = new List<Book>{
                            new Book("101", "Tom and jerry","william", 100, "series was action and visual humour."),
                            new Book("102", "Mickey Mouse","walt",  200, "Mickey Mouse a cartoon character."),
                            new Book("103", "Timon and Pumba","roberts", 300, "TimonandPumbaa is animated film The Lion King and its franchise."),
                            new Book("104", "Doraemon","hiroshi", 400, "Doraemon came to present age to help Nobita.")
                    };
                displayBookDetails(booklist);

                do
                {
                    Console.WriteLine();

                    Console.WriteLine("Enter number of your  choice");
                    Console.WriteLine(" Enter 1 : Add values to existing booklist");
                    Console.WriteLine(" Enter 2 : delete from existing list");
                    Console.WriteLine(" Enter 3 : display the description");
                    Console.WriteLine(" Enter 4 : display the the book details of specific id");
                    Console.WriteLine(" Enter 5 : edit the existing booklist");
                    Console.WriteLine(" Enter 6 : display all the book details");
                    Console.WriteLine(" Enter 7 : For Exit");


                    num = Convert.ToInt32(Console.ReadLine());
                    bool isContains = false;
                    int bookindex = 0;
                    string idvalue;

                    switch (num)
                    {

                        case 1:

                            int n = 0;
                            bool bookInput = false;
                            while (bookInput == false)
                            {
                                Console.WriteLine("enter no.of books you want to enter : ");
                                bookInput = Int32.TryParse(Console.ReadLine(), out n);

                            }
                            for (int i = 1; i <= n; i++)
                            {

                                Console.WriteLine("After adding");

                                string bookId, bookName, Author, description;
                                float price;
                                Console.WriteLine("BookId : ");
                                bookId = Console.ReadLine();

                                Console.WriteLine("BookName : ");
                                bookName = Console.ReadLine();

                                Console.WriteLine("Author : ");
                                Author = Console.ReadLine();

                                Console.WriteLine("Description : ");
                                description = Console.ReadLine();

                                Console.WriteLine("price : ");
                                bool result = Single.TryParse((Console.ReadLine()), out price);
                                if (result)
                                {
                                    booklist.Add(new Book(bookId, bookName, Author, price, description));
                                }
                            }
                            displayBookDetails(booklist);
                            break;

                        case 2:

                            Console.WriteLine("Enter Book id value you want to delete : ");
                            idvalue = Console.ReadLine();
                            foreach (Book item in booklist)
                            {
                                if (item.bookId == idvalue)
                                {
                                    bookindex = booklist.IndexOf(item);
                                    isContains = true;
                                }
                            }
                            if (isContains)
                            {
                                booklist.RemoveAt(bookindex);
                                Console.WriteLine();
                                Console.WriteLine("After deletion : ");
                                displayBookDetails(booklist);
                            }
                            else
                            {
                                Console.WriteLine("entered value is doesnt exist");
                                Console.WriteLine();
                            }
                            break;
                        case 3:

                            Console.WriteLine("Enter Book id value you want to display description : ");
                            idvalue = Console.ReadLine();
                            foreach (Book item in booklist)
                            {
                                if (item.bookId == idvalue)
                                {
                                    bookindex = booklist.IndexOf(item);
                                    isContains = true;
                                }
                            }
                            if (isContains)
                            {
                                Console.WriteLine("Description : " + booklist[bookindex].description);

                            }
                            else
                            {
                                Console.WriteLine("entered value is doesnt exist");
                                Console.WriteLine();
                            }


                        //Console.WriteLine("display description");
                        break;
                        case 4:
                            Console.WriteLine("Enter Book id value you want to display all details : ");
                            idvalue = Console.ReadLine();
                            foreach (Book item in booklist)
                            {
                                if (item.bookId == idvalue)
                                {
                                    bookindex = booklist.IndexOf(item);
                                    isContains = true;
                                }
                            }
                            if (isContains)
                            {
                                Console.WriteLine(booklist[bookindex]);

                            }
                            else
                            {
                                Console.WriteLine("entered value is doesnt exist");
                                Console.WriteLine();
                            }
                            break;

                        case 5:
                            Console.WriteLine("editing process");
                            do
                            {

                                string newbookId, newbookName, newauthor, newdescription;
                                float newprice;
                                Console.WriteLine("Enter number of your  choice");
                                Console.WriteLine(" Enter 1 : Enter value to edit bookId");
                                Console.WriteLine(" Enter 2 : Enter value to edit bookName");
                                Console.WriteLine(" Enter 3 : Enter value to edit author");
                                Console.WriteLine(" Enter 4 : Enter value to edit price");
                                Console.WriteLine(" Enter 5 : Enter value to edit description");
                                Console.WriteLine(" Enter 6 : Exit");
                                num1 = Convert.ToInt32(Console.ReadLine());
                                switch (num1)
                                {

                                    case 1:
                                        Console.WriteLine("Enter Book id value you want to edit book id: ");
                                        idvalue = Console.ReadLine();

                                        foreach (Book item in booklist)
                                        {
                                            if (item.bookId == idvalue)
                                            {
                                                Console.WriteLine("Enter bookId : ");
                                                newbookId = Console.ReadLine();
                                                bookindex = booklist.IndexOf(item);
                                                item.bookId = newbookId;
                                                isContains = true;

                                            }
                                        }
                                        if (isContains)
                                        {
                                        
                                            Console.WriteLine("After editing bookId : ");
                                            Console.WriteLine(booklist[bookindex]);
                                            Console.WriteLine();

                                        }
                                        else
                                        {
                                            Console.WriteLine("entered value is doesnt exist");
                                            Console.WriteLine();
                                        }

                                        break;

                                    case 2:
                                        Console.WriteLine("Enter Book id value you want to edit book name: ");
                                        idvalue = Console.ReadLine();

                                        foreach (Book item in booklist)
                                        {
                                            if (item.bookId == idvalue)
                                            {
                                                Console.WriteLine("Enter new bookName : ");
                                                newbookName = Console.ReadLine();
                                                bookindex = booklist.IndexOf(item);
                                                item.bookName = newbookName;
                                                isContains = true;

                                            }
                                        }
                                        if (isContains)
                                        {
                                            //displayBookDetails(booklist);
                                            Console.WriteLine("After editing bookName");
                                            Console.WriteLine(booklist[bookindex]);
                                            Console.WriteLine();

                                        }
                                        else
                                        {
                                            Console.WriteLine("entered value is doesnt exist");
                                            Console.WriteLine();
                                        }
                                        break;
                                    case 3:
                                        Console.WriteLine("Enter Book id value you want to edit author: ");
                                        idvalue = Console.ReadLine();
                                        foreach (Book item in booklist)
                                        {
                                            if (item.bookId == idvalue)
                                            {
                                                Console.WriteLine("Enter new bookAuthor : ");
                                                newauthor = Console.ReadLine();
                                                bookindex = booklist.IndexOf(item);
                                                item.Author = newauthor;
                                                isContains = true;

                                            }
                                        }
                                        if (isContains)
                                        {
                                            //displayBookDetails(booklist);
                                            Console.WriteLine("After editing book Author");
                                            Console.WriteLine(booklist[bookindex]);
                                            Console.WriteLine();

                                        }
                                        else
                                        {
                                            Console.WriteLine("entered value is doesnt exist");
                                             Console.WriteLine();
                                        }

                                        break;
                                    case 4:
                                        Console.WriteLine("Enter Book id value you want to edit price: ");
                                        idvalue = Console.ReadLine();
                                        foreach (Book item in booklist)
                                        {
                                            if (item.bookId == idvalue)
                                            {
                                                Console.WriteLine("Enter new bookprice : ");
                                                newprice = Convert.ToInt32(Console.ReadLine());
                                                bookindex = booklist.IndexOf(item);
                                                item.price = newprice;
                                                isContains = true;

                                            }
                                        }
                                        if (isContains)
                                        {
                                            //
                                            Console.WriteLine("After editing bookprice : ");
                                            
                                            Console.WriteLine(booklist[bookindex]);
                                            Console.WriteLine();

                                        }
                                        else
                                        {
                                            Console.WriteLine("entered value is doesnt exist");
                                            Console.WriteLine();
                                        }

                                        break;
                                    case 5:
                                        Console.WriteLine("Enter Book id value you want to edit description: ");
                                        idvalue = Console.ReadLine();
                                        foreach (Book item in booklist)
                                        {
                                            if (item.bookId == idvalue)
                                            {
                                                Console.WriteLine("Enter new bookdescription : ");
                                                newdescription = Console.ReadLine();
                                                bookindex = booklist.IndexOf(item);
                                                item.description = newdescription;
                                                isContains = true;

                                            }
                                        }
                                        if (isContains)
                                        {
                                            //displayBookDetails(booklist);
                                            Console.WriteLine("After editing bookId : ");
                                            Console.WriteLine(booklist[bookindex]);
                                            Console.WriteLine();

                                        }
                                        else
                                        {
                                            Console.WriteLine("entered value is doesnt exist");
                                            Console.WriteLine();
                                        }
                                        break;
                                }   
                            
                            } while (num1 != 6);    
                            break;
                        case 6:
                            displayBookDetails(booklist);
                        break;
                    }
                    Console.WriteLine();
                    Console.WriteLine("press ENTER for further process");

                    Console.ReadLine();
                } while (num != 7);
            }
        }
}



